export async function fetchLaptops() {
  try {
    const response = await fetch("./data/laptops.json");
    if (!response.ok) {
      throw new Error("Could not load laptop data.");
    }
    return await response.json();
  } catch (error) {
    throw error;
  }
}