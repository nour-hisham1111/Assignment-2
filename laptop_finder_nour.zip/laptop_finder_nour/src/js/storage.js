const FAVORITES_KEY = "student_laptop_favorites";
const THEME_KEY = "student_laptop_theme";

export const getFavorites = () => {
  const data = localStorage.getItem(FAVORITES_KEY);
  return data ? JSON.parse(data) : [];
};

export const isFavorite = (id) => {
  return getFavorites().includes(Number(id));
};

export function toggleFavorite(id) {
  const numericId = Number(id);
  const favorites = getFavorites();
  const updated = favorites.includes(numericId)
    ? favorites.filter((item) => item !== numericId)
    : [...favorites, numericId];
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
  return updated;
}

export function clearFavorites() {
  localStorage.setItem(FAVORITES_KEY, JSON.stringify([]));
}

export function getTheme() {
  return localStorage.getItem(THEME_KEY) || "battery";
}

export function saveTheme(theme) {
  localStorage.setItem(THEME_KEY, theme);
}