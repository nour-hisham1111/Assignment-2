import { fetchLaptops } from "./api.js";
import { getFavorites } from "./storage.js";
import { setupLayout } from "./ui.js";

setupLayout();

async function initHome() {
  const totalEl = document.getElementById("stat-total");
  const lowestEl = document.getElementById("stat-lowest");
  const favEl = document.getElementById("stat-favorites");
  const errorEl = document.getElementById("home-error");

  try {
    const laptops = await fetchLaptops();
    const totalCount = laptops.reduce((acc) => acc + 1, 0);
    const lowestPrice = laptops.reduce(
      (min, item) => (item.price < min ? item.price : min),
      laptops[0].price
    );

    totalEl.textContent = totalCount;
    lowestEl.textContent = `$${lowestPrice}`;
    favEl.textContent = getFavorites().length;
  } catch (error) {
    errorEl.textContent = "Failed to load statistics. Make sure you run the app on a local server.";
    errorEl.classList.remove("hidden");
  }
}

initHome();