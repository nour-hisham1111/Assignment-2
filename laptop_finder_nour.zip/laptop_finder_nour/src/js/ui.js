import { getTheme, saveTheme, isFavorite, toggleFavorite } from "./storage.js";

export function applySavedTheme() {
  const currentTheme = getTheme();
  if (currentTheme === "performance") {
    document.documentElement.setAttribute("data-theme", "performance");
  } else {
    document.documentElement.removeAttribute("data-theme");
  }
  updateThemeButtonText(currentTheme);
}

function updateThemeButtonText(theme) {
  const btn = document.getElementById("theme-toggle");
  if (btn) {
    btn.textContent = theme === "performance" ? "Battery Saver Mode" : "Performance Mode";
  }
}

export function setupLayout() {
  applySavedTheme();

  const themeBtn = document.getElementById("theme-toggle");
  if (themeBtn) {
    themeBtn.addEventListener("click", () => {
      const nextTheme = getTheme() === "performance" ? "battery" : "performance";
      saveTheme(nextTheme);
      applySavedTheme();
    });
  }

  const menuBtn = document.getElementById("mobile-menu-btn");
  const navMenu = document.getElementById("nav-menu");
  if (menuBtn && navMenu) {
    menuBtn.addEventListener("click", () => {
      navMenu.classList.toggle("hidden");
    });
  }
}

export function renderSkeletons(container, count = 6) {
  const items = Array.from({ length: count })
    .map(
      () => `
      <div class="laptop-card animate-pulse">
        <div class="h-40 bg-gray-300/40 rounded-lg mb-4"></div>
        <div class="h-5 bg-gray-300/40 rounded w-3/4 mb-2"></div>
        <div class="h-4 bg-gray-300/40 rounded w-1/2 mb-4"></div>
        <div class="h-8 bg-gray-300/40 rounded w-full"></div>
      </div>
    `
    )
    .join("");
  container.innerHTML = items;
}

export const createLaptopCard = (laptop, onFavoriteChange) => {
  const saved = isFavorite(laptop.id);
  const card = document.createElement("article");
  card.className = "laptop-card";
  card.innerHTML = `
    <div>
      <img src="${laptop.image}" alt="${laptop.name}" class="w-full h-40 object-contain mb-4 rounded-lg bg-white/50 p-2" />
      <div class="flex justify-between items-start gap-2 mb-1">
        <span class="text-xs uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[var(--color-accent)]/15 text-[var(--color-accent)]">${laptop.category}</span>
        <span class="text-lg font-extrabold text-[var(--color-accent)]">$${laptop.price}</span>
      </div>
      <h3 class="text-lg font-bold mt-1">${laptop.name}</h3>
      <p class="text-sm text-[var(--color-text-muted)] mb-3">${laptop.brand}</p>
      <ul class="text-sm space-y-1 mb-4 text-[var(--color-text-muted)]">
        <li>CPU: ${laptop.cpu}</li>
        <li>RAM / Storage: ${laptop.ramGB}GB / ${laptop.storageGB}GB</li>
        <li>Battery: ${laptop.batteryHours} hrs | Weight: ${laptop.weightKg} kg</li>
      </ul>
    </div>
    <div class="flex gap-2 mt-2">
      <a href="details.html?id=${laptop.id}" class="btn-action flex-1 text-sm">Details</a>
      <button type="button" class="fav-btn ${saved ? "btn-action" : "btn-outline"} text-sm">
        ${saved ? "Saved" : "Favorite"}
      </button>
    </div>
  `;

  const favBtn = card.querySelector(".fav-btn");
  favBtn.addEventListener("click", () => {
    toggleFavorite(laptop.id);
    const nowSaved = isFavorite(laptop.id);
    favBtn.textContent = nowSaved ? "Saved" : "Favorite";
    favBtn.className = `fav-btn ${nowSaved ? "btn-action" : "btn-outline"} text-sm`;
    if (onFavoriteChange) {
      onFavoriteChange();
    }
  });

  return card;
};