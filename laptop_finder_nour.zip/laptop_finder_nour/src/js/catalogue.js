import { fetchLaptops } from "./api.js";
import { setupLayout, renderSkeletons, createLaptopCard } from "./ui.js";

setupLayout();

const grid = document.getElementById("laptop-grid");
const countEl = document.getElementById("result-count");
const errorEl = document.getElementById("catalogue-error");
const searchInput = document.getElementById("search-input");
const categorySelect = document.getElementById("category-filter");
const maxPriceInput = document.getElementById("max-price-filter");
const minRamSelect = document.getElementById("min-ram-filter");
const sortSelect = document.getElementById("sort-select");

let allLaptops = [];

function applyFiltersAndRender() {
  const query = searchInput.value.trim().toLowerCase();
  const category = categorySelect.value;
  const maxPrice = Number(maxPriceInput.value);
  const minRam = Number(minRamSelect.value);
  const sortBy = sortSelect.value;

  const filtered = allLaptops.filter((laptop) => {
    const matchesSearch =
      laptop.name.toLowerCase().includes(query) ||
      laptop.brand.toLowerCase().includes(query);
    const matchesCategory = category === "all" || laptop.category === category;
    const matchesPrice = !maxPrice || laptop.price <= maxPrice;
    const matchesRam = !minRam || laptop.ramGB >= minRam;
    return matchesSearch && matchesCategory && matchesPrice && matchesRam;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === "price-asc") return a.price - b.price;
    if (sortBy === "price-desc") return b.price - a.price;
    if (sortBy === "battery-desc") return b.batteryHours - a.batteryHours;
    if (sortBy === "battery-asc") return a.batteryHours - b.batteryHours;
    if (sortBy === "weight-asc") return a.weightKg - b.weightKg;
    if (sortBy === "weight-desc") return b.weightKg - a.weightKg;
    return 0;
  });

  countEl.textContent = `Showing ${sorted.length} of ${allLaptops.length} laptops`;
  grid.innerHTML = "";

  if (sorted.length === 0) {
    grid.innerHTML = `<p class="col-span-full text-center py-10 text-lg text-[var(--color-text-muted)]">No laptops match your current filters.</p>`;
    return;
  }

  sorted.map((laptop) => grid.appendChild(createLaptopCard(laptop)));
}

async function initCatalogue() {
  renderSkeletons(grid, 6);
  try {
    allLaptops = await fetchLaptops();
    applyFiltersAndRender();
  } catch (error) {
    grid.innerHTML = "";
    errorEl.textContent = "Error loading laptops. Please run via a local server.";
    errorEl.classList.remove("hidden");
  }
}

[searchInput, categorySelect, maxPriceInput, minRamSelect, sortSelect].forEach((el) => {
  el.addEventListener("input", applyFiltersAndRender);
  el.addEventListener("change", applyFiltersAndRender);
});

initCatalogue();