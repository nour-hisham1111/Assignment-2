import { fetchLaptops } from "./api.js";
import { isFavorite, toggleFavorite } from "./storage.js";
import { setupLayout } from "./ui.js";

setupLayout();

async function initDetails() {
  const container = document.getElementById("details-container");
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id"));

  if (!id) {
    container.innerHTML = `<p class="text-center py-10 text-lg">No laptop selected. <a href="laptops.html" class="underline text-[var(--color-accent)]">Return to catalogue</a>.</p>`;
    return;
  }

  try {
    const laptops = await fetchLaptops();
    const laptop = laptops.find((item) => item.id === id);

    if (!laptop) {
      container.innerHTML = `<p class="text-center py-10 text-lg">Laptop not found. <a href="laptops.html" class="underline text-[var(--color-accent)]">Return to catalogue</a>.</p>`;
      return;
    }

    const specs = [
      ["Brand", laptop.brand],
      ["Category", laptop.category],
      ["Price", `$${laptop.price}`],
      ["Processor (CPU)", laptop.cpu],
      ["Memory (RAM)", `${laptop.ramGB} GB`],
      ["Storage", `${laptop.storageGB} GB`],
      ["Battery Life", `${laptop.batteryHours} hours`],
      ["Weight", `${laptop.weightKg} kg`],
      ["Screen Size", `${laptop.screenInches} inches`]
    ];

    const rowsHtml = specs
      .map(
        ([label, value]) => `
        <tr class="border-b border-[var(--color-border)]">
          <th class="py-3 px-4 text-left font-semibold">${label}</th>
          <td class="py-3 px-4 text-[var(--color-text-muted)]">${value}</td>
        </tr>
      `
      )
      .join("");

    const saved = isFavorite(laptop.id);

    container.innerHTML = `
      <div class="laptop-card">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <img src="${laptop.image}" alt="${laptop.name}" class="w-full max-h-72 object-contain rounded-lg bg-white/50 p-4" />
          <div>
            <span class="text-xs uppercase font-bold px-2 py-1 rounded bg-[var(--color-accent)]/15 text-[var(--color-accent)]">${laptop.category}</span>
            <h1 class="text-3xl font-bold mt-2">${laptop.name}</h1>
            <p class="text-2xl font-extrabold text-[var(--color-accent)] my-2">$${laptop.price}</p>
            <p class="text-[var(--color-text-muted)] mb-6">${laptop.description}</p>
            <div class="flex flex-wrap gap-3">
              <button id="detail-fav-btn" class="${saved ? "btn-action" : "btn-outline"}">
                ${saved ? "Saved in Favorites" : "Add to Favorites"}
              </button>
              <a href="compare.html" class="btn-action">Go to Compare</a>
            </div>
          </div>
        </div>
        <div class="mt-8 overflow-x-auto">
          <h2 class="text-xl font-bold mb-3">Full Specifications</h2>
          <table class="w-full border-collapse border border-[var(--color-border)] rounded-lg">
            <tbody>${rowsHtml}</tbody>
          </table>
        </div>
      </div>
    `;

    const favBtn = document.getElementById("detail-fav-btn");
    favBtn.addEventListener("click", () => {
      toggleFavorite(laptop.id);
      const nowSaved = isFavorite(laptop.id);
      favBtn.textContent = nowSaved ? "Saved in Favorites" : "Add to Favorites";
      favBtn.className = nowSaved ? "btn-action" : "btn-outline";
    });
  } catch (error) {
    container.innerHTML = `<p class="text-center py-10 text-red-500">Failed to load laptop details.</p>`;
  }
}

initDetails();