import { fetchLaptops } from "./api.js";
import { getFavorites } from "./storage.js";
import { setupLayout } from "./ui.js";

setupLayout();

const selectorContainer = document.getElementById("compare-selector");
const messageEl = document.getElementById("compare-message");
const tableWrapper = document.getElementById("compare-table-wrapper");

let favoriteLaptops = [];
let selectedIds = [];

function renderSelector() {
  if (favoriteLaptops.length === 0) {
    selectorContainer.innerHTML = `<p class="text-[var(--color-text-muted)]">No favorites saved yet. Add at least two laptops to favorites first.</p>`;
    return;
  }

  selectorContainer.innerHTML = favoriteLaptops
    .map((laptop) => {
      const checked = selectedIds.includes(laptop.id) ? "checked" : "";
      return `
        <label class="flex items-center gap-2 p-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-card)] cursor-pointer">
          <input type="checkbox" value="${laptop.id}" ${checked} class="form-control" />
          <span class="font-medium">${laptop.name} ($${laptop.price})</span>
        </label>
      `;
    })
    .join("");

  selectorContainer.querySelectorAll("input[type='checkbox']").forEach((checkbox) => {
    checkbox.addEventListener("change", (e) => {
      const id = Number(e.target.value);
      if (e.target.checked) {
        if (selectedIds.length >= 4) {
          e.target.checked = false;
          messageEl.textContent = "You can compare a maximum of 4 laptops at once.";
          messageEl.classList.remove("hidden");
          return;
        }
        messageEl.classList.add("hidden");
        selectedIds.push(id);
      } else {
        messageEl.classList.add("hidden");
        selectedIds = selectedIds.filter((item) => item !== id);
      }
      renderComparisonTable();
    });
  });
}

function renderComparisonTable() {
  const chosen = favoriteLaptops.filter((item) => selectedIds.includes(item.id));

  if (chosen.length < 2) {
    tableWrapper.innerHTML = `<p class="text-center py-8 text-[var(--color-text-muted)]">Select between 2 and 4 favorites above to compare them side by side.</p>`;
    return;
  }

  const bestPrice = Math.min(...chosen.map((l) => l.price));
  const bestRam = Math.max(...chosen.map((l) => l.ramGB));
  const bestStorage = Math.max(...chosen.map((l) => l.storageGB));
  const bestBattery = Math.max(...chosen.map((l) => l.batteryHours));
  const bestWeight = Math.min(...chosen.map((l) => l.weightKg));

  const rows = [
    { label: "Brand", getValue: (l) => l.brand, isBest: () => false },
    { label: "Category", getValue: (l) => l.category, isBest: () => false },
    { label: "Price", getValue: (l) => `$${l.price}`, isBest: (l) => l.price === bestPrice },
    { label: "CPU", getValue: (l) => l.cpu, isBest: () => false },
    { label: "RAM", getValue: (l) => `${l.ramGB} GB`, isBest: (l) => l.ramGB === bestRam },
    { label: "Storage", getValue: (l) => `${l.storageGB} GB`, isBest: (l) => l.storageGB === bestStorage },
    { label: "Battery Life", getValue: (l) => `${l.batteryHours} hrs`, isBest: (l) => l.batteryHours === bestBattery },
    { label: "Weight", getValue: (l) => `${l.weightKg} kg`, isBest: (l) => l.weightKg === bestWeight },
    { label: "Screen", getValue: (l) => `${l.screenInches}"`, isBest: () => false }
  ];

  const headerCells = chosen
    .map((l) => `<th class="p-4 text-left border border-[var(--color-border)] font-bold">${l.name}</th>`)
    .join("");

  const bodyRows = rows
    .map((row) => {
      const cells = chosen
        .map((laptop) => {
          const highlight = row.isBest(laptop)
            ? "bg-[var(--color-accent)]/20 font-bold text-[var(--color-accent)]"
            : "";
          return `<td class="p-4 border border-[var(--color-border)] ${highlight}">${row.getValue(laptop)}</td>`;
        })
        .join("");
      return `
        <tr>
          <th class="p-4 text-left border border-[var(--color-border)] bg-[var(--color-bg-card)]">${row.label}</th>
          ${cells}
        </tr>
      `;
    })
    .join("");

  tableWrapper.innerHTML = `
    <div class="overflow-x-auto rounded-xl border border-[var(--color-border)]">
      <table class="w-full border-collapse bg-[var(--color-bg-card)]">
        <thead>
          <tr>
            <th class="p-4 text-left border border-[var(--color-border)]">Specification</th>
            ${headerCells}
          </tr>
        </thead>
        <tbody>${bodyRows}</tbody>
      </table>
    </div>
  `;
}

async function initCompare() {
  try {
    const allLaptops = await fetchLaptops();
    const favIds = getFavorites();
    favoriteLaptops = allLaptops.filter((item) => favIds.includes(item.id));
    selectedIds = favoriteLaptops.slice(0, 3).map((item) => item.id);
    renderSelector();
    renderComparisonTable();
  } catch (error) {
    tableWrapper.innerHTML = `<p class="text-red-500">Failed to load comparison data.</p>`;
  }
}

initCompare();