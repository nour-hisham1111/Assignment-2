import { fetchLaptops } from "./api.js";
import { getFavorites, clearFavorites } from "./storage.js";
import { setupLayout, createLaptopCard } from "./ui.js";

setupLayout();

const grid = document.getElementById("favorites-grid");
const summaryEl = document.getElementById("favorites-summary");
const clearBtn = document.getElementById("clear-favorites-btn");

let allLaptops = [];

function renderFavoritesPage() {
  const favIds = getFavorites();
  const favLaptops = allLaptops.filter((item) => favIds.includes(item.id));

  grid.innerHTML = "";

  if (favLaptops.length === 0) {
    summaryEl.textContent = "Total: $0 | Average: $0";
    grid.innerHTML = `<p class="col-span-full text-center py-10 text-lg text-[var(--color-text-muted)]">You have no saved favorites yet. Browse the catalogue to add some.</p>`;
    return;
  }

  const totalPrice = favLaptops.reduce((sum, item) => sum + item.price, 0);
  const avgPrice = Math.round(totalPrice / favLaptops.length);
  summaryEl.textContent = `Saved: ${favLaptops.length} | Total Price: $${totalPrice} | Average Price: $${avgPrice}`;

  favLaptops.map((laptop) =>
    grid.appendChild(createLaptopCard(laptop, renderFavoritesPage))
  );
}

clearBtn.addEventListener("click", () => {
  clearFavorites();
  renderFavoritesPage();
});

async function initFavorites() {
  try {
    allLaptops = await fetchLaptops();
    renderFavoritesPage();
  } catch (error) {
    grid.innerHTML = `<p class="col-span-full text-center text-red-500">Failed to load favorites data.</p>`;
  }
}

initFavorites();