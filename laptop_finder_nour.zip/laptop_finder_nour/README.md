# Student Laptop Finder

A responsive web app built with HTML, ES Modules JavaScript, and Tailwind CSS 4.

## Setup & Build Instructions

1. Install dependencies:
   ```bash
   npm install